from genshinhelper import main 

def main_handler(event, context):
    main()
